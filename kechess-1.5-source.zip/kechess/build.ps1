param(
    [string] $Sdk = $env:ANDROID_HOME,
    [string] $Jdk = $env:JAVA_HOME,
    [string] $Output = (Join-Path $PSScriptRoot 'build/kechess.apk'),
    [string] $SigningKey = (Join-Path $PSScriptRoot 'build/kechess-dev.p12')
)
$ErrorActionPreference = 'Stop'
if (!$Sdk) { $Sdk = Join-Path $env:LOCALAPPDATA 'Android/Sdk' }
if (!$Jdk) { throw 'Set JAVA_HOME or pass -Jdk to a JDK 17 installation.' }
$env:JAVA_HOME = $Jdk
$env:Path = "$(Join-Path $Jdk 'bin');$env:Path"
$toolsDir = Join-Path $Sdk 'build-tools/36.0.0'
$android = Get-ChildItem (Join-Path $Sdk 'platforms') -Directory |
    Sort-Object { [version](($_.Name -replace '^android-', '') + $(if ($_.Name -notmatch '\.') { '.0' })) } -Descending |
    ForEach-Object { Join-Path $_.FullName 'android.jar' } |
    Where-Object { Test-Path $_ } | Select-Object -First 1
if (!$android) { throw 'Install Android SDK Platform 35 or later.' }
$buildDir = Join-Path $PSScriptRoot 'build'
$appDir = Join-Path $PSScriptRoot 'app'
$classes = Join-Path $buildDir 'classes'
$dex = Join-Path $buildDir 'dex'
New-Item -ItemType Directory -Force $buildDir,$classes,$dex,(Split-Path -Parent ([IO.Path]::GetFullPath($Output))),(Split-Path -Parent ([IO.Path]::GetFullPath($SigningKey))) | Out-Null

function Invoke-Executable($File, [string[]] $Arguments) {
    & $File @Arguments
    if ($LASTEXITCODE -ne 0) { throw "$File exited with code $LASTEXITCODE" }
}

$resources = Join-Path $buildDir 'resources.zip'
$unsigned = Join-Path $buildDir 'unsigned.apk'
$aligned = Join-Path $buildDir 'aligned.apk'
$classJar = Join-Path $buildDir 'classes.jar'
Invoke-Executable "$toolsDir/aapt2.exe" @('compile','--dir',"$appDir/res",'-o',$resources)
Invoke-Executable "$toolsDir/aapt2.exe" @('link','-o',$unsigned,'-I',$android,'--manifest',"$appDir/AndroidManifest.xml",'-A',"$appDir/assets",$resources)
Invoke-Executable "$Jdk/bin/javac.exe" @('--release','8','-encoding','UTF-8','-cp',$android,'-d',$classes,"$appDir/src/com/kechess/app/MainActivity.java")
Invoke-Executable "$Jdk/bin/jar.exe" @('cf',$classJar,'-C',$classes,'.')
Invoke-Executable "$toolsDir/d8.bat" @('--min-api','24','--lib',$android,'--output',$dex,$classJar)
Invoke-Executable "$Jdk/bin/jar.exe" @('uf',$unsigned,'-C',$dex,'classes.dex')
Invoke-Executable "$toolsDir/zipalign.exe" @('-f','4',$unsigned,$aligned)
# This key is for local installation and testing. Keep the generated file to sign updates.
if (!(Test-Path $SigningKey)) {
    Invoke-Executable "$Jdk/bin/keytool.exe" @('-genkeypair','-keystore',$SigningKey,'-storepass','kechess-local-dev',
        '-alias','kechess','-keyalg','RSA','-keysize','2048','-validity','10000','-dname','CN=kechess local build')
}
Invoke-Executable "$toolsDir/apksigner.bat" @('sign','--ks',$SigningKey,'--ks-key-alias','kechess',
    '--ks-pass','pass:kechess-local-dev','--v4-signing-enabled','false','--out',$Output,$aligned)
Invoke-Executable "$toolsDir/apksigner.bat" @('verify','--verbose',$Output)

