package com.kechess.app;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.WindowInsets;
import android.webkit.JavascriptInterface;
import android.webkit.MimeTypeMap;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.Collections;

public final class MainActivity extends Activity {
    private static final String HOST = "kechess.internal";
    private WebView web;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(228, 223, 221));
        getWindow().setNavigationBarColor(Color.rgb(228, 223, 221));
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(228, 223, 221));
        if (Build.VERSION.SDK_INT >= 35) {
            root.setOnApplyWindowInsetsListener((view, insets) -> {
                android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.systemBars()
                        | WindowInsets.Type.displayCutout() | WindowInsets.Type.ime());
                view.setPadding(bars.left, bars.top, bars.right, bars.bottom);
                return WindowInsets.CONSUMED;
            });
        }
        web = new WebView(this);
        web.setBackgroundColor(Color.rgb(228, 223, 221));
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        web.addJavascriptInterface(new AndroidActions(), "KechessAndroid");
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return true;
            }

            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (!HOST.equals(uri.getHost())) return null;
                String file = uri.getPath();
                if (file != null && file.matches("/[a-zA-Z0-9_./-]+") && !file.contains("..")) {
                    try {
                        String ext = file.substring(file.lastIndexOf('.') + 1);
                        String mime = ext.equals("js") ? "application/javascript" :
                                ext.equals("svg") ? "image/svg+xml" :
                                ext.equals("wasm") ? "application/wasm" :
                                ext.equals("css") ? "text/css" :
                                ext.equals("html") ? "text/html" :
                                MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext);
                        String encoding = (ext.equals("png") || ext.equals("wasm")) ? null : "UTF-8";
                        return new WebResourceResponse(mime, encoding, getAssets().open(file.substring(1)));
                    } catch (IOException ignored) { }
                }
                return new WebResourceResponse("text/plain", "UTF-8", 404, "Not Found",
                        Collections.emptyMap(), new ByteArrayInputStream(new byte[0]));
            }
        });
        root.addView(web, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);
        web.loadUrl("https://" + HOST + "/index.html");
    }

    @Override public void onBackPressed() {
        web.evaluateJavascript("window.kechessBack && window.kechessBack()", handled -> {
            if (!"true".equals(handled)) super.onBackPressed();
        });
    }

    @Override protected void onDestroy() {
        web.removeJavascriptInterface("KechessAndroid");
        ((FrameLayout) web.getParent()).removeView(web);
        web.destroy();
        super.onDestroy();
    }

    private final class AndroidActions {
        @JavascriptInterface public void copy(String value) {
            runOnUiThread(() -> getSystemService(ClipboardManager.class)
                    .setPrimaryClip(ClipData.newPlainText("kechess", value)));
        }

        @JavascriptInterface public void share(String value, String language) {
            String title = "ru".equals(language) ? "Поделиться" : "Share";
            runOnUiThread(() -> startActivity(Intent.createChooser(new Intent(Intent.ACTION_SEND)
                    .setType("text/plain").putExtra(Intent.EXTRA_TEXT, value), title)));
        }
    }
}
